# Zyra — Aplicación Front-End Funcional (Evidencia GA4-220501096-AA3-EV10)

Aplicación web front-end del proyecto formativo **Zyra**, orientada al bienestar emocional, seguimiento diario del estado de ánimo y acompañamiento interactivo.

- **Despliegue en producción:** https://zyra.juandiaz200811.workers.dev/
- **Repositorio:** https://github.com/zyraia2026-lab/Zyra-
- **Versión etiquetada:** `v1.0.0-ev10`
- **Programa:** Tecnólogo en Análisis y Desarrollo de Software (ADSO — Código 228118) — SENA CENIGRAF (Ficha 3404915)

## Equipo de Trabajo
- Juan Sebastián Díaz Manrique
- Nicol Pineda
- José Estrada
- Nicolás Vargas
- Miguel Torales

## Herramientas y Versiones
- HTML5 semántico, CSS3 moderno (Flexbox / Grid) y JavaScript
- Entorno de ejecución: Node.js (versión LTS vigente)
- Backend y servicios: Node.js, MongoDB Atlas y Cloudflare Workers
- Control de versiones y pruebas visuales: Git, GitHub y DevTools del navegador

## Flujos Prioritarios Implementados
1. **Acceso y verificación:** Inicio de sesión con correo/contraseña o proveedores externos y validación de código enviado al correo electrónico.
2. **Personalización inicial ("Sobre ti"):** Registro opcional de nombre preferido, identidad, año de nacimiento y frecuencia de ejercicio.
3. **Panel principal y seguimiento emocional:** Selección de estado de ánimo diario, consulta de historial emocional, resumen diario, racha y navegación hacia Test Emocional, Diario y Chat con Zyra.

## Instalación y Ejecución Local
1. Clonar el repositorio:
   ```bash
   git clone https://github.com/zyraia2026-lab/Zyra-.git
   ```
2. Ingresar a la carpeta del proyecto e instalar dependencias:
   ```bash
   cd Zyra-
   npm install
   ```
3. Crear el archivo de entorno a partir de `env.example` / `.env.example` (sin subir archivos `.env`, contraseñas, tokens ni datos personales).
4. Iniciar la aplicación o servidor según el script configurado en `package.json`:
   ```bash
   npm run dev
   ```

## Pruebas y Verificación
- Verificar flujos funcionales en interfaz (acceso, personalización "Sobre ti", selección de ánimo y navegación lateral).
- Revisar diseño adaptable en navegador con DevTools (móvil `375x812` y escritorio `1366x768` / `1920x1080`).
- Comprobar navegación por teclado (`Tab`), foco visible y contraste visual (incluyendo los botones en tonalidad verde esmeralda).

## Estructura de la Entrega
```text
Evidencia_10_Frontend_Proyecto/
├── Documento/
│   └── GA4-220501096-AA3-EV10_Informe_Frontend_Zyra_.pdf
├── Fuentes_o_Codigo/
│   ├── env.example
│   ├── index.html
│   ├── manifest.json
│   ├── package.json
│   ├── styles.css
│   └── sw.js
├── Pruebas_y_Resultados/
│   ├── 01_Flujo1_Acceso_Inicio_Sesion_Zyra.png
│   ├── 02_Flujo2_Personalizacion_Sobre_Ti_Zyra.png
│   ├── 03_Flujo3_Panel_Principal_Dashboard_Zyra.png
│   └── 04_Cambio_Visual_Botones_Verde_Esmeralda.png
└── README.md
```